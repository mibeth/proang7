export interface IMessage {
    msg: string;
    type: string;
}