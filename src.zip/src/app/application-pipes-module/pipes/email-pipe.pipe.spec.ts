import { EmailPipePipe } from './email-pipe.pipe';

describe('EmailPipePipe', () => {
  it('create an instance', () => {
    const pipe = new EmailPipePipe();
    expect(pipe).toBeTruthy();
  });
});
