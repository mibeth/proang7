import { ILogin } from "./interfaces/ILogin";

export class Login implements ILogin{
    email:string;
    password:string;

    constructor(){}
}