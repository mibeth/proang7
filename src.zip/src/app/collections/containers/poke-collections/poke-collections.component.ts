import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-poke-collections',
  templateUrl: './poke-collections.component.html',
  styleUrls: ['./poke-collections.component.css']
})
export class PokeCollectionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
