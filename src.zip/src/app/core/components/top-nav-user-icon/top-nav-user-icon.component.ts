import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-nav-user-icon',
  templateUrl: './top-nav-user-icon.component.html',
  styleUrls: ['./top-nav-user-icon.component.css']
})
export class TopNavUserIconComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
