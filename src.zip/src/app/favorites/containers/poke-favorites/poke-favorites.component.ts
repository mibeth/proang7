import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-poke-favorites',
  templateUrl: './poke-favorites.component.html',
  styleUrls: ['./poke-favorites.component.css']
})
export class PokeFavoritesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
